# IntentSync - System Architecture (Web-Signal Monitoring Layer)

## 1. Core Philosophy
IntentSync is a **personal web-signal monitoring layer**. It decouples intent (what the user wants) from timing (when it happens). It creates a "Readiness Score" for every intent and notifies only when that score crosses a threshold.

## 2. System Architecture

```mermaid
graph TD
    Ext[Chrome Extension] -->|Register Intent| API[API Server]
    
    subgraph "Signal Detection Engine"
        Scheduler -->|Trigger Scan| Worker[Scraper Worker]
        Worker -->|Fetch| Target[Target Page]
        Worker -->|Extract Signals| Analyzer[Signal Analyzer]
        
        Analyzer -->|Calculate Score| ScoringEngine[Readiness Scoring]
        ScoringEngine -->|Compare State| StateMemory[Status Memory]
        
        StateMemory -->|Significant Transition| Feed[Web Change Feed]
        Feed -->|High Confidence| Notifier[Notification Dispatcher]
    end
    
    Notifier -->|Chrome/Email| User
```

## 3. Data Model (State & Readiness)

```sql
CREATE TABLE intents (
    id UUID PRIMARY KEY,
    user_id UUID,
    url TEXT NOT NULL,
    template_type VARCHAR(50), -- 'application', 'release', 'content_update'
    current_readiness INT DEFAULT 0, -- 0-100%
    semantic_state VARCHAR(50), -- 'closed', 'announced', 'live', 'unknown'
    last_transition_at TIMESTAMP
);

CREATE TABLE snapshots (
    id UUID PRIMARY KEY,
    intent_id UUID,
    dom_hash VARCHAR(64),
    extracted_signals JSONB, -- { "has_form": true, "cta_text": "Apply Now" }
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE signal_feed (
    id UUID PRIMARY KEY,
    intent_id UUID,
    event_type VARCHAR(50), -- 'score_increase', 'state_flip', 'noise_filtered'
    description TEXT, -- "Readiness jumped to 90% due to 'Apply' button detection"
    created_at TIMESTAMP DEFAULT NOW()
);
```

## 4. Readiness Scoring Logic (0-100%)
Instead of binary alerts, we calculate a probability of actionability.

*   **Base Score**: 10% (Page exists)
*   **+20%**: "Coming Soon" removed.
*   **+40%**: Keyword "Apply" or "Register" detected near top of DOM.
*   **+30%**: New `<form>` element or `<a>` tag with external href detected.
*   **Threshold**: Notify user if Score > 85%.

## 5. Status Memory & Transitions
The system remembers the *previous* state to avoid redundant alerts.
*   *Transition*: `Closed` -> `Open` (ALERT)
*   *Transition*: `Open` -> `Open (Content Change)` (LOG TO FEED, NO ALERT)
*   *Transition*: `Open` -> `Closed` (LOG TO FEED)

## 6. Worker Scheduling
*   **Adaptive**: If readiness score is increasing (e.g., 40% -> 60%), increase poll frequency.
*   **Decay**: If score remains 0% for 30 days, suggest "Auto-Expire" to user.

## 7. Explainability
Every notification payload includes:
1.  **Trigger**: "State changed from 'Waitlist' to 'Live'"
2.  **Evidence**: "Found button text 'Join Now' and 2 new input fields."
3.  **Confidence**: "95% Readiness"
