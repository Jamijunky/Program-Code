export interface FeedItem {
  id: string;
  monitorId: string;
  type: 'score_increase' | 'state_flip' | 'noise_filtered' | 'system';
  description: string;
  timestamp: string;
  readinessDelta?: number;
}

export interface Monitor {
  id: string;
  title: string;
  url: string;
  condition: 'keyword' | 'visual' | 'link' | 'status_change';
  keywords?: string[];
  lastChecked: string;
  nextCheck: string;
  status: 'scanning' | 'idle' | 'alert' | 'error';
  changeSummary?: string;
  scanFrequency: string;
  readinessScore: number; // 0-100
  semanticState: string; // 'closed', 'announced', 'live', etc.
  confidenceScore: number; // System internal confidence
}

export const MOCK_MONITORS: Monitor[] = [
  {
    id: "1",
    title: "NVIDIA RTX 5090 Stock",
    url: "https://store.nvidia.com/en-us/",
    condition: "status_change",
    keywords: ["Add to Cart"],
    lastChecked: new Date(Date.now() - 1000 * 60 * 2).toISOString(),
    nextCheck: new Date(Date.now() + 1000 * 60 * 3).toISOString(),
    status: "scanning",
    scanFrequency: "5m",
    readinessScore: 85,
    semanticState: "checking_inventory",
    confidenceScore: 98,
  },
  {
    id: "2",
    title: "YC S26 Application",
    url: "https://www.ycombinator.com/apply",
    condition: "keyword",
    keywords: ["Apply Now"],
    lastChecked: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    nextCheck: new Date(Date.now() + 1000 * 60 * 15).toISOString(),
    status: "idle",
    scanFrequency: "1h",
    readinessScore: 15,
    semanticState: "closed",
    confidenceScore: 100,
  },
  {
    id: "3",
    title: "Taylor Swift Tour",
    url: "https://ticketmaster.com/artist/12345",
    condition: "link",
    lastChecked: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    nextCheck: new Date(Date.now() + 1000 * 60 * 60 * 4).toISOString(),
    status: "alert",
    changeSummary: "New link detected: 'Wembley Stadium'",
    scanFrequency: "6h",
    readinessScore: 92,
    semanticState: "tickets_available",
    confidenceScore: 85,
  },
];

export const MOCK_FEED: FeedItem[] = [
  {
    id: "f1",
    monitorId: "1",
    type: "score_increase",
    description: "Readiness jumped +40%: Found 'Add to Cart' button (disabled)",
    timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
    readinessDelta: 40
  },
  {
    id: "f2",
    monitorId: "3",
    type: "state_flip",
    description: "State transition: 'Announced' -> 'Tickets Available'",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
  },
  {
    id: "f3",
    monitorId: "2",
    type: "noise_filtered",
    description: "Ignored footer copyright year update (2025 -> 2026)",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
  }
];
