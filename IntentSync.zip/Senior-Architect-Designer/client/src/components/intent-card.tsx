import { Monitor } from "@/lib/mock-data";
import { ExternalLink, RefreshCw, AlertCircle, CheckCircle2, Terminal, BarChart3, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { formatDistanceToNow } from "date-fns";

interface MonitorCardProps {
  monitor: Monitor;
  onRefresh: (id: string) => void;
  onDelete: (id: string) => void;
}

export function MonitorCard({ monitor, onRefresh, onDelete }: MonitorCardProps) {
  const statusColors = {
    scanning: "border-blue-500/50 bg-blue-500/5 text-blue-600 dark:text-blue-400",
    idle: "border-muted-foreground/30 text-muted-foreground",
    alert: "border-green-500 bg-green-500/10 text-green-600 dark:text-green-400 shadow-[0_0_15px_rgba(34,197,94,0.2)]",
    error: "border-red-500/50 bg-red-500/5 text-red-600 dark:text-red-400",
  };

  const getReadinessColor = (score: number) => {
    if (score >= 85) return "bg-green-500";
    if (score >= 50) return "bg-yellow-500";
    return "bg-muted-foreground/30";
  };

  return (
    <Card className={`group relative transition-all duration-300 ${monitor.status === 'alert' ? 'ring-2 ring-green-500/20' : ''}`}>
      {/* Scanning Pulse Effect */}
      {monitor.status === 'scanning' && (
        <div className="absolute top-0 left-0 w-full h-[2px] bg-blue-500/20 overflow-hidden rounded-t-xl">
          <div className="h-full bg-blue-500 w-1/3 animate-[loading_1.5s_ease-in-out_infinite] translate-x-[-100%]" />
        </div>
      )}

      <CardHeader className="p-4 pb-2">
        <div className="flex justify-between items-start gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline" className={`h-5 text-[10px] px-1.5 font-mono uppercase tracking-wider ${statusColors[monitor.status]}`}>
                {monitor.status === 'scanning' && <RefreshCw className="h-3 w-3 mr-1 animate-spin" />}
                {monitor.status === 'alert' && <AlertCircle className="h-3 w-3 mr-1" />}
                {monitor.status}
              </Badge>
              <span className="text-[10px] font-mono text-muted-foreground px-1.5 border border-border/50 rounded flex items-center gap-1">
                <Terminal className="h-3 w-3" />
                {monitor.semanticState}
              </span>
            </div>
            <h3 className="font-semibold text-base truncate">{monitor.title}</h3>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground" onClick={() => onRefresh(monitor.id)}>
              <RefreshCw className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-4 pt-0">
        <div className="space-y-4">
          {/* Readiness Score */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
              <span>Readiness Score</span>
              <span>{monitor.readinessScore}%</span>
            </div>
            <Progress value={monitor.readinessScore} className="h-1.5" indicatorClassName={getReadinessColor(monitor.readinessScore)} />
          </div>

          <div className="font-mono text-xs space-y-2">
            {monitor.status === 'alert' ? (
              <div className="bg-green-500/10 border border-green-500/20 rounded p-2 text-green-700 dark:text-green-300">
                <div className="flex items-center gap-2 mb-1 font-bold">
                  <CheckCircle2 className="h-3.5 w-3.5" /> Actionable
                </div>
                <p className="opacity-90">{monitor.changeSummary}</p>
              </div>
            ) : (
               <div className="flex flex-col gap-1 text-muted-foreground/80">
                 <div className="flex justify-between border-b border-border/40 pb-1 mb-1">
                   <span>Last Scan</span>
                   <span className="text-foreground">{formatDistanceToNow(new Date(monitor.lastChecked))} ago</span>
                 </div>
                 <div className="flex justify-between">
                   <span>Next Check</span>
                   <span className="text-foreground">{formatDistanceToNow(new Date(monitor.nextCheck))}</span>
                 </div>
               </div>
            )}
          </div>
        </div>
      </CardContent>

      <CardFooter className="p-3 bg-secondary/30 border-t flex justify-between items-center text-xs text-muted-foreground">
        <div className="flex items-center gap-2 truncate max-w-[70%]">
          <img 
            src={`https://www.google.com/s2/favicons?domain=${new URL(monitor.url).hostname}`} 
            alt="" 
            className="h-3.5 w-3.5 opacity-70 grayscale group-hover:grayscale-0 transition-all" 
          />
          <span className="truncate font-mono opacity-70">{new URL(monitor.url).hostname}</span>
        </div>
        <a 
          href={monitor.url} 
          target="_blank" 
          rel="noreferrer" 
          className="hover:text-primary transition-colors flex items-center gap-1"
        >
          Source <ExternalLink className="h-3 w-3" />
        </a>
      </CardFooter>
    </Card>
  );
}
