import { Link, useLocation } from "wouter";
import { Zap, LayoutDashboard, Radio, History, Settings, Bell, Search, Plus, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface LayoutProps {
  children: React.ReactNode;
  onAddIntent: () => void;
}

export function Layout({ children, onAddIntent }: LayoutProps) {
  const [location] = useLocation();

  const isActive = (path: string) => location === path;

  return (
    <div className="flex h-screen bg-background overflow-hidden font-sans">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-sidebar flex flex-col hidden md:flex">
        <div className="p-6 flex items-center gap-2">
          <div className="bg-primary text-primary-foreground p-1.5 rounded-md">
            <Radio className="h-5 w-5" />
          </div>
          <span className="font-display font-bold text-lg tracking-tight">IntentSync</span>
        </div>

        <div className="px-4 py-2">
           <Button onClick={onAddIntent} className="w-full justify-start gap-2 font-medium shadow-md hover:shadow-lg transition-all" size="sm">
            <Plus className="h-4 w-4" /> New Monitor
          </Button>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
          <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest px-3 mb-2 mt-2">Console</div>
          <NavItem href="/dashboard" icon={<ActivityIcon />} active={isActive("/dashboard")}>
            Live Monitors
          </NavItem>
          <NavItem href="/dashboard/alerts" icon={<Bell className="h-4 w-4" />} active={isActive("/dashboard/alerts")}>
            Alerts <span className="ml-auto bg-primary/20 text-primary text-[10px] px-1.5 rounded-full">2</span>
          </NavItem>
          <NavItem href="/dashboard/history" icon={<History className="h-4 w-4" />} active={isActive("/dashboard/history")}>
            Scan History
          </NavItem>
          
          <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest px-3 mb-2 mt-8">System</div>
          <NavItem href="/dashboard/settings" icon={<Settings className="h-4 w-4" />} active={isActive("/dashboard/settings")}>
            Configuration
          </NavItem>
          <NavItem href="/dashboard/logs" icon={<Terminal className="h-4 w-4" />} active={isActive("/dashboard/logs")}>
            System Logs
          </NavItem>
        </nav>

        <div className="p-4 border-t border-border">
          <div className="bg-secondary/30 rounded-lg p-3 text-xs border border-border/50">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium text-muted-foreground">Worker Status</span>
              <span className="flex h-2 w-2 rounded-full bg-green-500"></span>
            </div>
            <div className="font-mono text-[10px] text-muted-foreground/70">
              Uptime: 99.9%<br/>
              Next sweep: 45s
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-secondary/5">
        <header className="h-16 border-b border-border bg-background/80 backdrop-blur-sm px-6 flex items-center justify-between sticky top-0 z-10">
          <div className="md:hidden flex items-center gap-2 mr-4">
            <Radio className="h-5 w-5 text-primary" />
          </div>
          
          <div className="flex-1 max-w-md relative hidden sm:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Filter monitors by keyword or URL..." 
              className="pl-9 bg-background border-border/60 focus:bg-background focus:border-primary transition-all font-mono text-sm" 
            />
          </div>

          <div className="flex items-center gap-4 ml-auto">
             <div className="hidden lg:flex items-center gap-2 text-xs text-muted-foreground font-mono bg-secondary/50 px-3 py-1.5 rounded-full border border-border/50">
               <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
               Engine Active
             </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-9 w-9 rounded-full">
                  <Avatar className="h-9 w-9 border border-border">
                    <AvatarImage src="https://github.com/shadcn.png" alt="@user" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">John Doe</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      john@example.com
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Profile</DropdownMenuItem>
                <DropdownMenuItem>Billing</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Log out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <div className="flex-1 overflow-auto p-6 md:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}

function NavItem({ href, icon, children, active }: { href: string, icon: any, children: React.ReactNode, active: boolean }) {
  return (
    <Link href={href}>
      <div className={`
        flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer select-none
        ${active 
          ? "bg-primary/10 text-primary border border-primary/20" 
          : "text-muted-foreground hover:bg-secondary hover:text-foreground border border-transparent"}
      `}>
        {icon}
        {children}
      </div>
    </Link>
  );
}

function ActivityIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
  )
}
