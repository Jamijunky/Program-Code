import { Radio, Search, ShieldCheck, Zap, ArrowRight, Eye, MousePointerClick, BellRing, BarChart3 } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="min-h-screen bg-background flex flex-col font-sans selection:bg-primary/20">
      {/* Navigation */}
      <nav className="border-b border-border/40 backdrop-blur-md fixed w-full z-50 bg-background/80">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-primary text-primary-foreground p-1 rounded-md">
              <Radio className="h-5 w-5" />
            </div>
            <span className="font-display font-bold text-xl tracking-tight">IntentSync</span>
          </div>
          
          <div className="flex items-center gap-6">
            <a href="#features" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Methodology</a>
            <Link href="/dashboard">
              <Button size="sm" className="font-medium">Open Console</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6 overflow-hidden">
        <div className="container mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-in-slide z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary/50 border border-border text-xs font-mono font-medium text-secondary-foreground">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
              SYSTEM ONLINE
            </div>
            
            <h1 className="text-5xl lg:text-7xl font-display font-bold leading-[1.1] tracking-tight">
              A Personal Web-Signal<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-600">Monitoring Layer.</span>
            </h1>
            
            <p className="text-xl text-muted-foreground max-w-lg leading-relaxed">
              Don't set reminders for things you can't control. IntentSync watches the web's semantic state and notifies you only when action is actually possible.
            </p>
            
            <div className="flex items-center gap-4">
              <Link href="/dashboard">
                <Button size="lg" className="h-12 px-8 text-base shadow-lg shadow-primary/20 transition-all hover:shadow-primary/30 hover:-translate-y-0.5">
                  Start Observation <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="h-12 px-8 text-base bg-transparent gap-2">
                <img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Google_Chrome_icon_%28February_2022%29.svg" className="h-5 w-5" alt="Chrome" />
                Add to Chrome
              </Button>
            </div>
          </div>
          
          <div className="relative lg:h-[600px] flex items-center justify-center animate-in-slide" style={{animationDelay: '0.2s'}}>
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/10 to-transparent rounded-3xl blur-3xl opacity-50"></div>
            
            {/* Abstract Tech Visual */}
            <div className="relative w-full max-w-lg aspect-square">
               <div className="absolute inset-0 border border-dashed border-primary/30 rounded-full animate-[spin_60s_linear_infinite]"></div>
               <div className="absolute inset-12 border border-primary/20 rounded-full animate-[spin_40s_linear_infinite_reverse]"></div>
               
               {/* Center Console */}
               <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 bg-card/90 backdrop-blur border border-border shadow-2xl rounded-xl p-5 space-y-4">
                 <div className="flex items-center justify-between border-b border-border/50 pb-2">
                   <div className="flex gap-1.5">
                     <div className="w-2.5 h-2.5 rounded-full bg-red-500/50"></div>
                     <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50"></div>
                     <div className="w-2.5 h-2.5 rounded-full bg-green-500/50"></div>
                   </div>
                   <span className="text-[10px] font-mono text-muted-foreground">SIGNAL_DETECTED</span>
                 </div>
                 
                 <div className="space-y-3">
                   <div>
                     <div className="flex justify-between text-[10px] font-mono mb-1 text-muted-foreground">
                       <span>READINESS SCORE</span>
                       <span className="text-primary">92%</span>
                     </div>
                     <div className="h-1.5 w-full bg-secondary rounded-full overflow-hidden">
                       <div className="h-full bg-primary w-[92%]"></div>
                     </div>
                   </div>

                   <div className="bg-secondary/20 p-3 rounded border border-border/50">
                      <div className="text-[10px] font-mono text-muted-foreground mb-1">{'>'} REASON</div>
                      <div className="text-xs font-medium">Found "Apply Now" CTA</div>
                      <div className="text-xs font-medium text-green-600 mt-1">+ Input Form Detected</div>
                   </div>
                 </div>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-20 bg-secondary/30 border-y border-border/50">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-display font-bold mb-4">Readiness, Not Reminders.</h2>
            <p className="text-muted-foreground">We calculate an "Action Readiness Score" for every page you watch. You only get interrupted when confidence is high.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<BarChart3 className="h-6 w-6 text-primary" />}
              title="Readiness Scoring"
              description="We analyze the page structure. A 'Coming Soon' page has 10% readiness. A page with an 'Apply' button has 90%. We track the difference."
            />
            <FeatureCard 
              icon={<ShieldCheck className="h-6 w-6 text-blue-500" />}
              title="State Memory"
              description="We remember previous states. If a page flips from 'Closed' to 'Open', we know it's a critical transition, not just a typo fix."
            />
            <FeatureCard 
              icon={<BellRing className="h-6 w-6 text-orange-500" />}
              title="Explainable Alerts"
              description="Our notifications tell you WHY we alerted you. 'Readiness jumped 40% because a registration form appeared.'"
            />
          </div>
        </div>
      </section>
      
      <footer className="py-12 border-t border-border mt-auto">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <Radio className="h-5 w-5 text-muted-foreground" />
            <span className="font-display font-bold text-lg text-muted-foreground">IntentSync</span>
          </div>
          <p className="text-sm text-muted-foreground">© 2026 IntentSync Inc. Infrastructure for intent.</p>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: any, title: string, description: string }) {
  return (
    <div className="bg-card p-8 rounded-xl border border-border shadow-sm hover:shadow-md transition-all group">
      <div className="mb-6 bg-background p-3 rounded-lg inline-block border border-border/50 shadow-sm group-hover:scale-110 transition-transform">{icon}</div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </div>
  );
}
