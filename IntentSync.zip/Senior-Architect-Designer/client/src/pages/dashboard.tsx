import { useState } from "react";
import { Layout } from "@/components/layout";
import { MonitorCard } from "@/components/intent-card";
import { MOCK_MONITORS, MOCK_FEED, Monitor } from "@/lib/mock-data";
import { Button } from "@/components/ui/button";
import { Filter, PlayCircle, Plus, Terminal, Activity, ArrowUpRight } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatDistanceToNow } from "date-fns";

export default function Dashboard() {
  const [monitors, setMonitors] = useState<Monitor[]>(MOCK_MONITORS);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const { toast } = useToast();

  const activeMonitors = monitors.filter(m => m.status !== 'error');
  const alertCount = monitors.filter(m => m.status === 'alert').length;

  const handleRefresh = (id: string) => {
    setMonitors(prev => prev.map(m => m.id === id ? { ...m, status: 'scanning' } : m));
    toast({
      title: "Manual Scan Initiated",
      description: "Worker dispatched to fetch latest snapshot.",
    });
    
    // Simulate scan finish
    setTimeout(() => {
       setMonitors(prev => prev.map(m => m.id === id ? { ...m, status: 'idle', lastChecked: new Date().toISOString() } : m));
    }, 2000);
  };

  const handleDelete = (id: string) => {
    setMonitors(prev => prev.filter(m => m.id !== id));
    toast({
      title: "Monitor Deleted",
      description: "Stopped watching resource.",
      variant: "destructive",
    });
  };

  const handleAddMonitor = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const newMonitor: Monitor = {
      id: Math.random().toString(36).substr(2, 9),
      title: formData.get('title') as string,
      url: formData.get('url') as string || 'https://example.com',
      condition: 'keyword',
      keywords: ["Apply Now"],
      lastChecked: new Date().toISOString(),
      nextCheck: new Date(Date.now() + 1000 * 60 * 60).toISOString(),
      status: 'idle',
      scanFrequency: '1h',
      readinessScore: 10,
      semanticState: 'initialized',
      confidenceScore: 100,
    };
    
    setMonitors([newMonitor, ...monitors]);
    setIsAddModalOpen(false);
    toast({
      title: "Monitor Active",
      description: "Initial snapshot created. Observation started.",
    });
  };

  return (
    <Layout onAddIntent={() => setIsAddModalOpen(true)}>
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in-slide">
        
        {/* Main Content Area (Monitors) */}
        <div className="lg:col-span-8 space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-display font-bold tracking-tight">Signal Monitors</h1>
              <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                <span className="flex h-2 w-2 rounded-full bg-green-500"></span>
                {activeMonitors.length} active monitors
                <span className="text-border mx-1">|</span>
                {alertCount} actionable signals
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button onClick={() => setIsAddModalOpen(true)} size="sm" className="gap-2 shadow-lg shadow-primary/20">
                <Plus className="h-4 w-4" /> New Monitor
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {monitors.map((monitor) => (
              <MonitorCard 
                key={monitor.id} 
                monitor={monitor} 
                onRefresh={handleRefresh}
                onDelete={handleDelete}
              />
            ))}
          </div>
        </div>

        {/* Right Sidebar (Web Change Feed) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-card rounded-xl border border-border shadow-sm h-full max-h-[calc(100vh-8rem)] flex flex-col">
            <div className="p-4 border-b border-border bg-secondary/10 flex items-center justify-between">
              <div className="flex items-center gap-2 font-medium">
                <Activity className="h-4 w-4 text-primary" />
                Signal Feed
              </div>
              <Badge variant="outline" className="text-[10px] font-mono">LIVE</Badge>
            </div>
            
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-6 relative before:absolute before:inset-y-0 before:left-[11px] before:w-[2px] before:bg-border/50">
                {MOCK_FEED.map((item) => (
                  <div key={item.id} className="relative pl-8">
                    {/* Timeline Dot */}
                    <div className={`
                      absolute left-0 top-1 w-6 h-6 rounded-full border-2 border-background flex items-center justify-center z-10
                      ${item.type === 'score_increase' ? 'bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-400' : ''}
                      ${item.type === 'state_flip' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400' : ''}
                      ${item.type === 'noise_filtered' ? 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400' : ''}
                    `}>
                      {item.type === 'score_increase' && <ArrowUpRight className="h-3 w-3" />}
                      {item.type === 'state_flip' && <Activity className="h-3 w-3" />}
                      {item.type === 'noise_filtered' && <Terminal className="h-3 w-3" />}
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-mono text-muted-foreground">{formatDistanceToNow(new Date(item.timestamp))} ago</span>
                        {item.readinessDelta && (
                          <span className="text-green-600 font-bold">+{item.readinessDelta}% Ready</span>
                        )}
                      </div>
                      <p className="text-sm font-medium leading-tight">{item.description}</p>
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                         On <span className="underline decoration-dotted">{MOCK_MONITORS.find(m => m.id === item.monitorId)?.title || 'Unknown Monitor'}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>
        </div>

      </div>

      {/* Add Monitor Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Terminal className="h-5 w-5 text-primary" />
              Initialize Monitor
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleAddMonitor} className="grid gap-6 py-4">
            
            <div className="space-y-3">
              <Label className="text-xs font-mono uppercase text-muted-foreground">Target Resource</Label>
              <div className="flex gap-2">
                <Input name="url" placeholder="https://..." defaultValue="https://openai.com/careers" className="font-mono text-sm" />
                <Button type="button" variant="outline" className="shrink-0 font-mono text-xs">
                  Analyze Page
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-2">
                 <Label>Template</Label>
                 <Select name="template" defaultValue="application">
                   <SelectTrigger>
                     <SelectValue />
                   </SelectTrigger>
                   <SelectContent>
                     <SelectItem value="application">Application Opening</SelectItem>
                     <SelectItem value="release">Product Release</SelectItem>
                     <SelectItem value="content">Content Update</SelectItem>
                     <SelectItem value="custom">Custom Logic</SelectItem>
                   </SelectContent>
                 </Select>
               </div>
               <div className="space-y-2">
                 <Label>Frequency</Label>
                 <Select name="frequency" defaultValue="1h">
                   <SelectTrigger>
                     <SelectValue />
                   </SelectTrigger>
                   <SelectContent>
                     <SelectItem value="5m">Every 5m (High Velocity)</SelectItem>
                     <SelectItem value="1h">Hourly</SelectItem>
                     <SelectItem value="6h">Every 6 Hours</SelectItem>
                   </SelectContent>
                 </Select>
               </div>
            </div>

            <div className="flex justify-end gap-2 mt-2">
              <Button type="button" variant="ghost" onClick={() => setIsAddModalOpen(false)}>Cancel</Button>
              <Button type="submit" className="gap-2">
                <PlayCircle className="h-4 w-4" /> Start Observation
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
