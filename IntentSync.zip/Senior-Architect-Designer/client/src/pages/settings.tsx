import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, Shield, Smartphone, Globe } from "lucide-react";

export default function Settings() {
  return (
    <Layout onAddIntent={() => {}}>
      <div className="max-w-4xl mx-auto space-y-8 animate-in-slide">
        <div>
          <h2 className="text-2xl font-display font-bold">Settings</h2>
          <p className="text-muted-foreground">Manage your account, notifications, and integration preferences.</p>
        </div>

        <Tabs defaultValue="notifications" className="space-y-6">
          <TabsList>
            <TabsTrigger value="notifications" className="gap-2"><Bell className="h-4 w-4" /> Notifications</TabsTrigger>
            <TabsTrigger value="integrations" className="gap-2"><Globe className="h-4 w-4" /> Integrations</TabsTrigger>
            <TabsTrigger value="account" className="gap-2"><Shield className="h-4 w-4" /> Account</TabsTrigger>
          </TabsList>

          <TabsContent value="notifications" className="space-y-6">
            <div className="bg-card rounded-xl border border-border p-6 space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-1">Email Notifications</h3>
                <p className="text-sm text-muted-foreground mb-4">Choose what updates you want to receive via email.</p>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="daily-digest" className="flex flex-col gap-1">
                      <span>Daily Digest</span>
                      <span className="font-normal text-xs text-muted-foreground">A summary of your upcoming intents every morning.</span>
                    </Label>
                    <Switch id="daily-digest" defaultChecked />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <Label htmlFor="missed-reminders" className="flex flex-col gap-1">
                      <span>Missed Reminders</span>
                      <span className="font-normal text-xs text-muted-foreground">Get an email if you miss a browser notification.</span>
                    </Label>
                    <Switch id="missed-reminders" defaultChecked />
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-lg font-medium mb-1">Browser Notifications</h3>
                <p className="text-sm text-muted-foreground mb-4">Configure how Chrome alerts you.</p>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="browser-alerts" className="flex flex-col gap-1">
                      <span>Desktop Alerts</span>
                      <span className="font-normal text-xs text-muted-foreground">Show native notifications when intents are triggered.</span>
                    </Label>
                    <Switch id="browser-alerts" defaultChecked />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <Label htmlFor="sound" className="flex flex-col gap-1">
                      <span>Notification Sound</span>
                      <span className="font-normal text-xs text-muted-foreground">Play a subtle sound with alerts.</span>
                    </Label>
                    <Switch id="sound" />
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="integrations" className="space-y-6">
            <div className="bg-card rounded-xl border border-border p-6">
              <h3 className="text-lg font-medium mb-4">Connected Calendars</h3>
              <div className="flex items-center justify-between p-4 border border-border rounded-lg mb-4">
                <div className="flex items-center gap-4">
                  <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold">G</div>
                  <div>
                    <div className="font-medium">Google Calendar</div>
                    <div className="text-sm text-muted-foreground">Connected as john@example.com</div>
                  </div>
                </div>
                <Button variant="outline" size="sm">Disconnect</Button>
              </div>
              <Button variant="outline" className="w-full gap-2">
                <PlusIcon /> Connect New Calendar
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="account">
             <div className="bg-card rounded-xl border border-border p-6 space-y-4">
                <div className="grid gap-2">
                  <Label>Email</Label>
                  <Input value="john@example.com" readOnly />
                </div>
                <div className="grid gap-2">
                  <Label>Password</Label>
                  <Button variant="outline" className="w-fit">Change Password</Button>
                </div>
             </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}

function PlusIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
  )
}
